from extensions import db, bcrypt
from sqlalchemy import text, exc
from flask_jwt_extended import create_access_token


# SQL table creation
def create_user_tables():
    # User table
    user_table_sql = text("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(120) UNIQUE NOT NULL,
            phone_number VARCHAR(20) DEFAULT NULL,
            password VARCHAR(64) NOT NULL, 
            modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )ENGINE=InnoDB;
    """)
    with db.engine.begin() as connection:
        connection.execute(user_table_sql)

def create_product_tables():
    # catalogue tables
    product_table_sql = text("""
        CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category ENUM('Boards','Apparel','Gear') NOT NULL,
            product_name VARCHAR(120) NOT NULL,
            brand VARCHAR(120) NOT NULL,
            size VARCHAR(120) NOT NULL,
            colour VARCHAR(120),
            traction_colour VARCHAR(120),
            shape VARCHAR(120),
            quantity INT NOT NULL DEFAULT 0,
            price DECIMAL(6,2) NOT NULL DEFAULT 0.00,
            image VARCHAR(256),
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            update_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )ENGINE=InnoDB;
    """)
    with db.engine.begin() as connection:
        connection.execute(product_table_sql)

def initialize_database():
    """Create user tables if they don't exist before the first request."""
    create_user_tables()
    create_product_tables()

### CRUD USER ###
#CREATE USER
def create_user(email, phone_number, password):
    try:
        # Hashed the password
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        # Insert into users table
        user_sql = text("""
        INSERT INTO users (email, phone_number, password) VALUES (:email, :phone_number, :password);
        """)

        db.session.execute(user_sql, {'email': email, 'phone_number': phone_number, 'password': hashed_password})
        
        # Fetch the last inserted user_id
        user_id = db.session.execute(text('SELECT LAST_INSERT_ID();')).fetchone()[0] 

        db.session.commit()
        return user_id
    
    except Exception as e:
        # Rollback the transaction in case of error
        db.session.rollback()
        raise e   

#GET USER
def get_user_by_id(user_id):
    try:
        sql = text("SELECT id, email, phone_number, password FROM users WHERE id = :user_id;")
        result = db.session.execute(sql, {'user_id': user_id})
        user = result.fetchone()

        # No need to commit() as no changes are being written to the database
        if user:
            # Convert the result into a dictionary if not None
            user_details = user._asdict()
            return user_details
        else:
            return None
    except Exception as e:
        # Rollback the transaction in case of error
        db.session.rollback()
        raise e


### CRUD PRODUCT ###
# Create product
def create_product(category, product_name, brand, size, colour, traction_colour, shape, quantity, price, image):
    try: 
        product_table_sql = text("""
        INSERT INTO products (category, product_name, brand, size, colour, traction_colour, shape, quantity, price, image) VALUES (:category, :product_name, :brand, :size, :colour, :traction_colour, :shape, :quantity, :price, :image);
        """)
        db.session.execute(product_table_sql, {'category': category, 'product_name' : product_name, 'brand' : brand, 'size' : size, 'colour' : colour, 'traction_colour' : traction_colour, 'shape' : shape, 'quantity' : quantity, 'price' : price, 'image': image})
        product_id = db.session.execute(text('SELECT LAST_INSERT_ID();')).fetchone()[0] 

        db.session.commit()
        return product_id
    
    except Exception as e:
        # Rollback the transaction in case of error
        db.session.rollback()
        raise e   

def get_product_by_id(product_id):
    try:
        sql = text("SELECT id, category, product_name, brand, size, colour, shape, quantity, price, image FROM products WHERE id = :product_id;")
        result = db.session.execute(sql, {'product_id': product_id})
        products = result.fetchone()

        # No need to commit() as no changes are being written to the database
        if products:
            # Convert the result into a dictionary if not None
            product_details = products._asdict()
            return product_details
        else:
            return None
    except Exception as e:
        # Rollback the transaction in case of error
        db.session.rollback()
        raise e